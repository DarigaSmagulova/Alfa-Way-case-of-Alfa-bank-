from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from . import views


urlpatterns = [
    path('createquiz/',views.Quiz,name='quiz'),
    path('exam/<username>/',views.get_quiz,name='exam'),
    path('exam/<username>/begin_test',views.responses,name='begin_test')
]