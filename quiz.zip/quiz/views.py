from django.shortcuts import render,redirect
from .forms import AddQuestions,AddQuiz,AddResponse,QuestionFormSet,ResponseFormSet
from .models import Response,Question,Quiz as Qz
# Create your views here
from django.template.defaulttags import register
from django.contrib.auth.models import User

@register.filter
def index(QuerySet,i):
    return QuerySet[i]

@register.filter
def index_with_content(QuerySet,i):
    return QuerySet[i].content

@register.filter
def get_range(value):
    return range(value)

def Quiz(request):
    form = QuestionFormSet()
    form2 = AddQuiz()
    if request.method == 'POST':
        forms = QuestionFormSet(request.POST)
        forms2 = AddQuiz(request.POST)
        if forms2.is_valid():
            forms2.save()
            for i in forms:
                if i.is_valid():
                    content = i.cleaned_data.get('content')
                    print(content)
                    instance = Question.objects.create(content=content)
                    instance.quiz.add(Qz.objects.get(title=forms2.cleaned_data['title']))
                    instance.save()
    return render(request,'user_auth/addquiz.html',{'form':form,'form2':form2})

def responses(request,username):
    quiz_id = request.GET.get('quiz')
    questions = Question.objects.filter(quiz=Qz.objects.get(id=quiz_id))
    if request.method == 'GET':
        form = ResponseFormSet()
        form.extra = len(questions)
        return render(request, 'user_auth/take_test.html',
                      {'form': form, 'questions': questions, 'range': range(len(form))})

    if request.method == 'POST':
        forms = ResponseFormSet(request.POST,request.FILES)
        count = 0
        print(len(questions))
        print(len(forms))
        print(username)
        for i in forms:
            if i.is_valid():
                instance = Response.objects.create(score=i.cleaned_data.get('score'),user=User.objects.get(username=username),question=questions[count])
                instance.save()
            count = count + 1
        return redirect('/')

def get_quiz(request,username):
    return render(request,'user_auth/get_quiz.html',{'obj':Qz.objects.all()})