import datetime as dt
from django import forms
from .models import *
from django.forms import formset_factory


class AddQuiz(forms.ModelForm):
    class Meta:
        model = Quiz
        fields = ["title"]

    def save(self, commit=True):
        get,created = Quiz.objects.get_or_create(title=self.cleaned_data['title'])
        return get


class AddQuestions(forms.ModelForm):
    class Meta:
        model = Question
        fields = ["content"]


QuestionFormSet = formset_factory(AddQuestions)


class AddResponse(forms.ModelForm):
    class Meta:
        model = Response
        fields = ['score']


ResponseFormSet = formset_factory(AddResponse)