from django.contrib import admin
from .models import Employee_levels
# Register your models here.
admin.site.register(Employee_levels)
