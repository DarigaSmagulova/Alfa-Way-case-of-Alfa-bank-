from django.urls import path
from . import views
from .views import EmploeeView


urlpatterns = [
    path('',views.upg_requests, name='dashboard'),
    path('profile/<username>',EmploeeView.as_view(),name = 'profile')
]
