from django.apps import AppConfig


class DhConfig(AppConfig):
    name = 'DH'
