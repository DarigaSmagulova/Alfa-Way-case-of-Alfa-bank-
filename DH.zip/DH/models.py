from django.db import models
from django.contrib.auth.models import User
import datetime


class Employee_levels(models.Model):
    employee = models.ForeignKey(User, related_name='+', on_delete=models.CASCADE)#models.CharField(max_length=30, unique=True)
    speciality = models.CharField(max_length=80)#models.ForeignKey(Profile,on_delete=models.CASCADE) # DONT FORGET TO CHANGE!!!!
    #created_at = models.DateTimeField(auto_now_add=True)
    cur_level=models.IntegerField(default=0)
    exp_level=models.IntegerField(default=1)
    test_date = models.DateField(null=True)
    test_time= models.TimeField(null=True)
    type_of_test=models.BooleanField(default=True)
    class Meta:
        ordering = ['test_date','-type_of_test']
    def __str__(self):
        return f'{self.employee.first_name + " " + self.employee.last_name}'
#Employee_levels.objects.order_by('test_date')

# class DateQuerySet(models.QuerySet):
#
#     def occurring_in_day(self, year, month, day):
#         try:
#             picked_date = datetime.date(day, month, year )
#         except (TypeError, ValueError):
#             return self.none()
#
#         return self.filter(
#             test_date=picked_date,
#             test_time=picked_date
#         )
#
