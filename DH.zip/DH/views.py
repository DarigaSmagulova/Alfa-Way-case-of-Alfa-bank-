from .models import Employee_levels
from django.shortcuts import render,get_object_or_404, redirect, reverse
from django.views.generic import View
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from user_auth.forms import UserUpdateForm, ProfileUpdateForm
from soft_skills.models import Skill

#from rest_framework.decorators import detail_route, list_route
#from rest_framework.response import Response
#from rest_framework import viewsets



# Create your views here.
@login_required
def upg_requests(request):
    upgrades= Employee_levels.objects.all()
    return render(request, 'DH/dashboard.html', {'upgrades': upgrades})

class EmploeeView(View):
    # #@list_route(methods=['get'], url_path='profile/<username>/upgrade')
    # def user_profile(self,request,username):
    #     get_object_or_404(Employee_levels, employee=username)
    #     form={'username': User.objects.get(username=username)}
    #     return render(request, 'user_auth/profile.html',form)#, {'upgrades': upgrades})
    #    # return Response(UserSerializer(user).data, status=status.HTTP_200_OK)
    def get(self, request, username):
        u_profile = UserUpdateForm(instance=request.user)
        p_profile = ProfileUpdateForm(instance=request.user.profile)
        skills = Skill.objects.filter(user=User.objects.get(username=username))
        form = {'u_profile': u_profile, 'p_profile': p_profile, 'username': User.objects.get(username=username),
                'skills': skills}
        return render(request, 'user_auth/profile.html', form)
