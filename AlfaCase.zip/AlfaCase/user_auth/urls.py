from django.urls import path,include
from . import views
from .views import RegisterView,ProfileView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.index,name='index'),
    path('register/',RegisterView.as_view(),name='register'),
    path('profile/',ProfileView.as_view(),name = 'profile'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

