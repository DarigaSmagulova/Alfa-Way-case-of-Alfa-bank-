from django.contrib.auth.decorators import login_required
from django.shortcuts import render,redirect
from user_auth.forms import UserCreationForm
from django.contrib.auth import authenticate,login
from .forms import UserUpdateForm,ProfileUpdateForm

# Create your views here.
def index(request):
    return render(request,'user_auth/index.html')

def register(request):
    if request.method=='POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username=username,password=password)
            login(request,user)
            return redirect('index')
    else:
        form = UserCreationForm()
    context = {'form':form}
    return render(request,'registration/register.html',context)


@login_required()
def profile(request):
    if request.method == 'POST':
        u_profile = UserUpdateForm(request.POST, instance=request.user)
        p_profile = ProfileUpdateForm(request.POST,request.FILES,instance=request.user.profile)
        if u_profile.is_valid() and p_profile.is_valid():
            u_profile.save()
            p_profile.save()
            return redirect('profile')
    else:
        u_profile = UserUpdateForm(instance=request.user)
        p_profile = ProfileUpdateForm(instance=request.user.profile)
    form = {'u_profile':u_profile,'p_profile':p_profile}
    return render(request,'user_auth/profile.html',form)