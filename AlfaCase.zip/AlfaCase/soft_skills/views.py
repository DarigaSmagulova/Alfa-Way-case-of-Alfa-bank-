from django.shortcuts import render,redirect
from .forms import AddSkill
# Create your views here.
def ApplySkill(request):
    if request.method == 'POST':
        skillform = AddSkill(request.POST)
        if skillform.is_valid():
            skillform.save()
            return redirect('skill')
    else:
        skillform = AddSkill()
    form = {'skillform':skillform}
    return render(request,'user_auth/skill.html',form)
