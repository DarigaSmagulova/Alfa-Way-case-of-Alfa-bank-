import json

from django.contrib.auth.decorators import login_required
from django.core import serializers
from django.http import HttpResponse
from django.shortcuts import render, redirect
from .forms import AddSkill
from django.contrib.auth.models import User
from soft_skills.models import Skill
from django.views.generic import View
from django.urls import resolve

# Create your views here.

class SkillView(View):
    def get(self, request):
        skillform = AddSkill()

        if request.path.split('/')[len(request.path.split('/')) - 2]=='soft':
            s = Skill.objects.filter(user=request.user,type='soft')
            allSkills = Skill.objects.filter(type='soft')
        elif request.path.split('/')[len(request.path.split('/'))-2]=='hard':
            s = Skill.objects.filter(user=request.user,type='hard')
            allSkills = Skill.objects.filter(type='hard')
        form = {'skillform': skillform, 'list_of_skills':serializers.serialize('json', s), 'all_of_skills':serializers.serialize('json',allSkills)}
        return render(request, 'user_auth/skill.html', form)

    def post(self, request):
        current_page = request.path.split('/')[len(request.path.split('/')) - 2]
        a = request.POST.getlist('the_post[]')
        for i in range(len(a)):
            form,created = Skill.objects.get_or_create(
                name=a[i],type=current_page
            )
            form.user.add(request.user)
        instance = Skill.objects.filter(user = request.user,type=current_page)
        for i in instance:
            if i.name not in a:
                Skill.objects.get(name=i.name).delete()

        return HttpResponse(
            json.dumps({'message': 'successfully added'}),
            content_type="application/json"
        )


    

