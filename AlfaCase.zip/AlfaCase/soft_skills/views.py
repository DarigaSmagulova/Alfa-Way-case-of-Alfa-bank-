from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .forms import AddSkillForm
from django.contrib.auth.models import User
from soft_skills.models import Skill
from django.views.generic import View
from .forms import SkillFormSet

# Create your views here.

class SkillView(View):
    def get(self, request):
        formset = SkillFormSet(request.GET or None)
        return render(request, 'user_auth/skill.html', {'formset':formset})


    def post(self,request):
        formset = SkillFormSet(request.POST,request.FILES)
        if formset.is_valid():
            for form in formset:
                name = form.cleaned_data.get('name')
                print(form.cleaned_data)
                print(name)
                if name:
                    print(len(formset))
                    skillform = Skill.objects.create(
                        name=name
                    )
                    skillform.user.add(request.user)
            return redirect('skill')

    #def post(self, request):
    #    skillform = AddSkillForm(request.POST)
    #    if skillform.is_valid():
    #        form = Skill.objects.create(
    #            name=skillform.cleaned_data['name']
    #        )
    #        form.user.add(request.user)
    #        return redirect('skill')
