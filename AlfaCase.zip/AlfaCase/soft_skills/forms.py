from django import forms
from .models import Skill
from .choices import *
from django.forms import formset_factory


class AddSkillForm(forms.Form):
    name = forms.ChoiceField(choices=STATUS_CHOICES, required=True)


SkillFormSet = formset_factory(AddSkillForm)
