from django import forms
from .models import Skill
class AddSkill(forms.ModelForm):
    class Meta:
        model = Skill
        fields = ['name']