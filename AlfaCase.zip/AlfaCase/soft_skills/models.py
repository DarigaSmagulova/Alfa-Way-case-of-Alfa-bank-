from django.db import models
from django.contrib.auth.models import User
from .choices import *
from django.db.models import Q


# Create your models here.
class Skill(models.Model):
    name = models.CharField(max_length=20)
    user = models.ManyToManyField(User)
    type = models.CharField(max_length=10)

    def __str__(self):
        return f'{self.name} Skill'
