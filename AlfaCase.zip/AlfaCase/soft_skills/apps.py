from django.apps import AppConfig


class SoftSkillsConfig(AppConfig):
    name = 'soft_skills'
