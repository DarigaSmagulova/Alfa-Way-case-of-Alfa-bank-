STATUS_CHOICES = [
    ('Java', ("Java")),
    ('Python', ("Python")),
    ('Android', ("Android")),
    ('Php', ("PHP")),
    ('Web', ("WEB"))
]